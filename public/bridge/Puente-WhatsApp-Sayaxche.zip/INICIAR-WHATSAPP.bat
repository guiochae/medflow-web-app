@echo off
title WhatsApp Bridge - Hospital Multimedica Sayaxche
color 0A
cd /d "%~dp0"

echo =====================================================================
echo       HOSPITAL MULTIMEDICA SAYAXCHE - PUENTE DE WHATSAPP
echo =====================================================================
echo.
echo [1/2] Iniciando microservicio en esta computadora...

set "PATH=%~dp0node;%PATH%"

for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":3001" ^| findstr /I "LISTENING ESCUCHANDO"') do (
    taskkill /PID %%a /F >nul 2>&1
)

echo [2/2] Microservicio iniciado exitosamente en: http://127.0.0.1:3001
echo.
echo *********************************************************************
echo  * Vuelve a la pantalla de la clinica en tu navegador web.
echo  * El CODIGO QR aparecera automaticamente en la pantalla.
echo  * MANTEN ESTA VENTANA ABIERTA mientras uses el sistema.
echo *********************************************************************
echo.

node server.js
echo.
echo El servicio se ha detenido. Presiona cualquier tecla para salir...
pause >nul
